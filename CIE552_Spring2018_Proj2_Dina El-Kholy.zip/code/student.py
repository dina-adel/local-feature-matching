import cv2
import scipy
import numpy as np
import math

import scipy
from scipy import signal
from scipy import misc
from scipy.spatial import distance
from scipy import signal as sig
from skimage.feature import peak_local_max
from scipy.spatial.distance import cdist
from skimage.feature import corner_harris, corner_peaks, corner_subpix

from operator import itemgetter


def subblock_hist_bin_counts(patch, feature_width):
    sub_block_dim = int(feature_width/4)
    patch_dim=patch.shape[0]
    feature= []
    step=sub_block_dim-1;
    i=0;  end_i=step
    c=0
    while end_i < patch_dim:
        j = 0;
        end_j = step;
        while end_j < patch_dim:

            c+=1
            block = patch[i:end_i+1, j:end_j+1]
            hist, edges= np.histogram(block, bins=8, range=(-180,180), density= False)
            feature.append(hist.transpose())
            j = end_j+1; end_j= j+step


        i = end_i + 1
        end_i= i + step
    feature= np.array(feature)
    return feature




def get_interest_points(image, feature_width):
    """
    :params:
    :image: a grayscale or color image (your choice depending on your implementation)
    :feature_width:

    :returns:
    :xs: an np array of the x coordinates of the interest points in the image
    :ys: an np array of the y coordinates of the interest points in the image

    :optional returns (may be useful for extra credit portions):
    :confidences: an np array indicating the confidence (strength) of each interest point
    :scale: an np array indicating the scale of each interest point
    :orientation: an np array indicating the orientation of each interest point

    """

    xs = []
    ys = []
    unfil_R = np.zeros(image.shape)
    #For the implementation, I used this video lecture: https://www.youtube.com/watch?v=_qgKQGsuKeQ
    #First, compute the x and y derivatives
    #Sobel filter can be used for computing derivatives

    kernel_x = np.array([[-1, 0, 1],[-2, 0, 2],[-1, 0, 1]])
    kernel_y = np.array([[1, 2, 1], [0, 0, 0], [-1, -2, -1]])
    #Second, get the 3 images; convolve the image with the filters
    Ix = sig.convolve2d(image,kernel_x,mode='same')
    Iy = sig.convolve2d(image,kernel_y,mode='same')
    Ixx = cv2.GaussianBlur(Ix**2,(31,31),sigmaX=1.5,sigmaY=1.5)
    Iyy = cv2.GaussianBlur(Iy**2,(31,31),sigmaX=1.5,sigmaY=1.5)
    Ixy = cv2.GaussianBlur(Ix*Iy,(31,31),sigmaX=1.5,sigmaY=1.5)
    #Third,feature window
    img_h = image.shape[0]
    img_w = image.shape[1]
    window = math.ceil(feature_width/2)
    #looping windows to find the corners in the image
    for y in range(window, img_h - window):
        for x in range(window, img_w - window):
            Sxx = np.sum(Ixx [y - window:y + window + 1, x - window:x + window + 1])
            Syy = np.sum(Iyy [y - window:y + window + 1, x - window:x + window + 1])
            Sxy = np.sum(Ixy [y - window:y + window + 1, x - window:x + window + 1])
    #Fourth, compute the Harris Response
            #R = detM - k*traceM**2 or R = detM/traceM
            detM = (Sxx*Syy)-(Sxy**2)
            traceM = Sxx+Syy
            R= detM - (0.093 * traceM**2) #0.06 based on search and recommenditions
            #append points to lists
            unfil_R [y,x] = R
    #find the max 150 ground truths
    cv2.normalize(unfil_R, unfil_R, 0, 1, cv2.NORM_MINMAX)
    peaks = peak_local_max(unfil_R,exclude_border=1,num_peaks=500)
    for item in peaks:
        xs.append(item[1])
        ys.append(item[0])
    xs = np.array(xs)
    ys = np.array(ys)
    return xs, ys



def get_features(image, x, y, feature_width, sigma=0.5):

    n_interest_points = x.shape[0]


    """"
    :params:
    :image: a grayscale or color image (your choice depending on your implementation)
    :x: np array of x coordinates of interest points
    :y: np array of y coordinates of interest points
    :feature_width: in pixels, is the local feature width. You can assume
                    that feature_width will be a multiple of 4 (i.e. every cell of your
                    local SIFT-like feature will have an integer width and height).
    If you want to detect and describe features at multiple scales or
    particular orientations you can add input arguments.

    :returns:
    :features: np array of computed features. It should be of size
            [len(x) * feature dimensionality] (for standard SIFT feature
            dimensionality is 128)

    """


    n_rows= image.shape[0]; n_cols= image.shape[1]

    #initialize 3d array to store gradient magnitude and angle at each pixel
    gradients_of_image= np.zeros((n_rows,n_cols,2))




    gaussian_kernel= cv2.getGaussianKernel(5,sigma );
    filtered_img = signal.correlate2d(image, gaussian_kernel, boundary='symm', mode='same')

    #getting gradient magnitude and angle for each pixel

    gx, gy = np.gradient(filtered_img)
    magnitudes = np.sqrt(gx ** 2 + gy ** 2)
    orientations = np.arctan(np.divide(gy, gx))
    nn = np.isnan(orientations)
    orientations[nn == True] = 90
    orientations= np.degrees(orientations)


   # gradients_of_image= np.concatenate(gradients_of_image,magnitudes,axis=2)
   # gradients_of_image = np.concatenate(gradients_of_image, orientations, axis=2)

    patch_orientations= np.zeros((feature_width, feature_width, n_interest_points), dtype= float)

    features = np.zeros((n_interest_points, 128), dtype=float)
    temp_feature= np.zeros(128)
    for i in range( n_interest_points):
        patch_orientations[:,:,i]= orientations[y[i]-8: y[i]+8, x[i]-8:x[i]+8];
        temp_feature= subblock_hist_bin_counts(patch_orientations[:,:,i], feature_width)

        Norm= np.linalg.norm(temp_feature, 2)
        temp_feature= temp_feature/ Norm
        temp_feature[temp_feature>0.2]=0.2
        Norm = np.linalg.norm(temp_feature, 2)
        temp_feature = temp_feature / Norm

        features[i,:]= np.reshape(temp_feature.transpose(), (128))


    return features










    # This is a placeholder - replace this with your features!



def match_features(im1_features, im2_features):

    """
    :params:
    :im1_features: an np array of features returned from get_features() for interest points in image1
    :im2_features: an np array of features returned from get_features() for interest points in image2

    :returns:
    :matches: an np array of dimension k x 2 where k is the number of matches. The first
            column is an index into im1_features and the second column is an index into im2_features
    :confidences: an np array with a real valued confidence for each match
    """

    threshold= 0.9997
    cv2.normalize(im1_features, im1_features, 0, 1, cv2.NORM_MINMAX)
    cv2.normalize(im2_features, im2_features, 0, 1, cv2.NORM_MINMAX)
    n_pt1= im1_features.shape[0]; npt2=im2_features.shape[0]
    f_index= np.zeros((n_pt1,2))
    ratio = np.zeros((n_pt1,1))
    dist= cdist(im1_features, im2_features)
    cv2.normalize(dist, dist, 0, 1, cv2.NORM_MINMAX)
    #sort rows and get sort indices
    indices= np.zeros(dist.shape).astype(int)
    sorted=  np.zeros(dist.shape)

    for i in range(dist.shape[0]):
        indices[i, :] = np.argsort(dist[i,:]).astype(int)
        row = dist[i,:]
        sorted[i,:]   = row[np.array(indices[i, :])]
        #row =sorted[i,:]
        #x = np.isnan(row)
        #row[x]=0
        #sorted[i, :] = row

    #summed= np.sum(sorted, axis=1)
    ratio= np.divide(sorted[:,0], sorted[:,1])
    f_index[:,0]= np.array(list(range(0, n_pt1)))
    f_index[:,1]= np.array(indices[:,0])
    nn_th = ratio  < threshold
    matches = [f_index[nn_th, 0], f_index[nn_th, 1]];
    confidences = ratio[nn_th];
    cv2.normalize(confidences, confidences, 0, 1, cv2.NORM_MINMAX)

    ind_conf= np.zeros(confidences.shape)
    sorted_conf = np.zeros(confidences.shape)


    ind_conf = np.argsort(confidences)
    sorted_conf = confidences[ind_conf]
    sorted_conf= sorted_conf[0:100]
    ind_conf= ind_conf[0:100]
    confidences= sorted_conf[::-1]
    ind_conf= ind_conf[::-1]
    matches= np.array(matches).transpose()
    matches= matches[ind_conf,:]


    return matches, confidences